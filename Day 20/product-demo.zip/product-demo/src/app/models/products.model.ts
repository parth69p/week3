// this model file will have interface defination for the product
export interface Product{
    id:number;
    name:string;
    price:number;
    inStock: boolean;
    description:string; 
}